
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'chaunceyau',
  applicationName: 'requesto-functions',
  appUid: 'HPGNMtpV0M8jtnRw3w',
  orgUid: 'g9Qt37b0nPDbx4tPbc',
  deploymentUid: 'c9e84d1d-814d-49bc-8b90-7f2481565840',
  serviceName: 'serverless-functions',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.12',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-functions-dev-deleteSubscription', timeout: 6 };

try {
  const userHandler = require('./delete-subscription.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}