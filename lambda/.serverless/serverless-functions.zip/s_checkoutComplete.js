
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'chaunceyau',
  applicationName: 'requesto-functions',
  appUid: 'HPGNMtpV0M8jtnRw3w',
  orgUid: 'g9Qt37b0nPDbx4tPbc',
  deploymentUid: '6f3d3097-0163-4780-8173-74beaef7d0a7',
  serviceName: 'serverless-functions',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.12',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-functions-dev-checkoutComplete', timeout: 6 };

try {
  const userHandler = require('./checkout-complete.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}